This font is free for PERSONAL USE only.
I really appreciate your support. I would like to share fonts created by me & Blue Curve Designstudio for free for personal use.
By doing so, your donation will help me to continue creating more fonts.

Please contact to purchase COMMERCIAL LICENSE: halfpenny37@gmail.com
or https://www.behance.net/ed67b3fc
or https://vk.com/public211353617

thank you
Dimitri Antonov